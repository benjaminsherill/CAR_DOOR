﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security;
using System.Security.Permissions;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyDescription("Generic Diagnostic Software")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Tester Present Specialist Automotive Solutions")]
[assembly: AssemblyCopyright("Copyright © Jack Leighton 2024")]
[assembly: AssemblyTitle("Generic Diagnostic Tool")]
[assembly: AssemblyProduct("Generic Diagnostic Tool")]
[assembly: AssemblyTrademark("Tester Present Specialist Automotive Solutions")]
[assembly: ComVisible(false)]
[assembly: Guid("1360f679-2391-4ab9-90ba-00514672580e")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: SecurityPermission(SecurityAction.RequestMinimum, SkipVerification = true)]
